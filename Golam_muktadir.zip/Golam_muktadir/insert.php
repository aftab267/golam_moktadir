<?php
$connect=mysqli_connect('localhost','root','','moktadir');

$emp_name= $_POST['emp_name'];
$fathers_name= $_POST['fathers_name'];
$mothers_name= $_POST['mothers_name'];
$sql="INSERT INTO employee_info(emp_name,father_name,mother_name) VALUES ('$emp_name','$fathers_name','$mothers_name')";
mysqli_query($connect,$sql);



?>

<?php

$connect=mysql_connect('localhost','root','','moktadir');
$_POST['emp_name'];
$_POST['fathers_name'];
$_POST['mothers_name'];
?>
