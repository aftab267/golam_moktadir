 <?php
//$x = 1;

//while($x <= 5) {
  //echo "aftab <br>";
  //$x++;
//}
 $multi=array('name'=>'peocock','fathers_name'=>'kazi aftabur Rahman','mothers_name'=>'nowsin laila susmita','address'=>array('road'=>'26/7 tajmohol road','block'=>'c'));
 echo $multi['address']['block'];

?> 
